﻿using System;

namespace TicTacToe
{
    public class Board
    {
        public char[] arr { get; set; }
        public Board()
        {

        }
        public Board(char[] array)
        {
            arr = array;
        }
        public override string ToString()
        {
            return ("     |     |      \n") +
            String.Format("  {0}  |  {1}  |  {2}\n", arr[1], arr[2], arr[3]) +
            String.Format("_____|_____|_____ \n") + 
            String.Format("     |     |      \n") +
            String.Format("  {0}  |  {1}  |  {2}\n", arr[4], arr[5], arr[6]) +
            String.Format("_____|_____|_____ \n") +
            String.Format("     |     |      \n") +
            String.Format("  {0}  |  {1}  |  {2}\n", arr[7], arr[8], arr[9]) +
            String.Format("     |     |      \n");
        }
    }
}
