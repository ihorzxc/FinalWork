﻿using System;
using System.Threading;

namespace TicTacToe
{
    public class Program
    {
        static void Main(string[] args)
        {
            string player1, player2;
            Console.WriteLine("Enter player1 name:");
            player1 = Console.ReadLine();
            Console.WriteLine("Enter player2 name:");
            player2 = Console.ReadLine();
            Board board = new Board();
            IGame game = new TicTacToeGame(board, player1, player2);
            game.StartGameSicle();
          
        }

    }
}
